from gluon.scheduler import Scheduler
import time
import calendar
import serial
import re

port = 'COM5'


def temp():
    timeStamp = calendar.timegm(time.gmtime())
    ser = serial.Serial()
    ser.port = port
    ser.baudrate = 9600
    ser.timeout = 1
    ser.setDTR(False)
    ser.open()  # while True:
    # ser.write('sensors')

    while True:
        ser.write('t1')
        temp1 = ser.readline()
        print "Inkomend signaal "
        if temp1 != '':
            print "temp1 = " + temp1
            savedata("sensor1", temp1, timeStamp)
            break
    while True:
        ser.write('t2')
        temp2 = ser.readline()
        # print "Inkomend signaal "
        if temp2 != '':
            print "temp2 = " + temp2
            savedata("sensor2", temp2, timeStamp)
            break
    while True:
        ser.write('t3')
        temp3 = ser.readline()
        # print "Inkomend signaal "
        if temp3 != '':
            print "temp3 = " + temp3
            savedata("sensor3", temp3, timeStamp)
            break
    while True:
        ser.write('l1')
        light1 = ser.readline()
        # print "Inkomend signaal "
        if light1 != '':
            print "light1 = " + light1
            savelichtdata("sensor1", light1, timeStamp)
            break
    while True:
        ser.write('l2')
        light2 = ser.readline()
        # print "Inkomend signaal "
        if light2 != '':
            print "light2 = " + light2
            savelichtdata("sensor2", light2, timeStamp)
            break
    while True:
        ser.write('l3')
        light3 = ser.readline()
        # print "Inkomend signaal "
        if light3 != '':
            print "light3 = " + light3
            savelichtdata("sensor3", light3, timeStamp)
            break
    ser.close()

    test = db(db.thresholds.type == "Temperatuur").select(db.thresholds.value)
    value = test[0].value

    # if int(value) < temp1:
    #    print("Te hoge temperatuur")


def savedata(name, data, tijdstip):
    rows = db(db.sensor.naam == name).select()
    row = rows[0]
    db.data.insert(sensor=row.id, temperatuur=data, tijd=tijdstip)
    db.commit()


def savelichtdata(name, data, tijdstip):
    rows = db(db.sensor.naam == name).select()
    row = rows[0]
    db.lightdata.insert(sensor=row.id, licht=data, tijd=tijdstip)


def tijd1():
    ser = serial.Serial(port, 9600, timeout=1)
    #while True:
    ser.write('11')
     #   sunrise = ser.readline()
        # print "Inkomend signaal "
      #  if sunrise != '':
            #    print "sunrise = " + sunrise
       #     break


def tijd2():
    ser = serial.Serial(port, 9600, timeout=1)
    #while True:
    ser.write('22')
     #   sunrise = ser.readline()
        # print "Inkomend signaal "
      #  if sunrise != '':
            #    print "sunrise = " + sunrise
       #     break


def tijd3():
    ser = serial.Serial(port, 9600, timeout=1)
    #while True:
    ser.write('33')
    #    sunrise = ser.readline()
        # print "Inkomend signaal "
     #   if sunrise != '':
            #    print "sunrise = " + sunrise
      #      break


def thres():
    ser = serial.Serial(port, 9600, timeout=1)
    hallo = db(db.scheduler_task.function_name == "thres").select(db.scheduler_task.vars)
    for var in hallo:
        hallo = re.search(r"\d+", str(var)).group()

    ser.write('25')


mysched = Scheduler(db, tasks=dict(temp1=temp, tijd1=tijd1, thres=thres, tijd2=tijd2, tijd3=tijd3))
